package kz.aitu.oop.assignment6;

public class ModernChair implements Chair {
    @Override
    public void soft() {
        System.out.println("chair is not soft");
    }

    @Override
    public void pose() {
        System.out.println("You can sit on chair");
    }
}

