package kz.aitu.oop.assignment6;
public class ArtDecorativeSofa implements Sofa{
    @Override
    public void soft() {
        System.out.println("Sofa is not soft");
    }

    @Override
    public void pose() {
        System.out.println("You can sit and lay on sofa");
    }
}
