package kz.aitu.oop.assignment6;

public class ModernSofa implements Sofa {
    @Override
    public void soft() {
        System.out.println("sofa is soft");
    }

    @Override
    public void pose() {
        System.out.println("You can sit and lay on sofa");
    }
}