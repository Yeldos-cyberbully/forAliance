package kz.aitu.oop.assignment6;

public class ArtDecorativeChair implements Chair {
    @Override
    public void soft() {
        System.out.println("Chair is soft");
    }

    @Override
    public void pose() {
        System.out.println("You can sit on chair");
    }
}


