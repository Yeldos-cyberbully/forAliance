package kz.aitu.oop.assignment6;

public interface Sofa {
    public void soft();
    public void pose();
}
