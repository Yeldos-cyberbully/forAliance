package kz.aitu.oop.assignment6;


public class VictorianFurnetureFactory implements FurnitureFactory{
    @Override
    public Chair createChair() { return new VictorianChair(); }

    @Override
    public Sofa createSofa() {
        return new VictorianSofa();
    }

    @Override
    public CoffeeTable createCoffeeTable() {
        return new VictorianCoffeTable();
    }
}
