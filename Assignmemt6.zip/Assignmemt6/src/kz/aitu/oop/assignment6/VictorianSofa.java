package kz.aitu.oop.assignment6;

public class VictorianSofa implements Sofa {
    @Override
    public void soft() {
        System.out.println("Sofa is soft");
    }

    @Override
    public void pose() {
        System.out.println("You can sit and lay on sofa");
    }
}
