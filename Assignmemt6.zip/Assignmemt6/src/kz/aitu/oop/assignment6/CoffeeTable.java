package kz.aitu.oop.assignment6;

public interface CoffeeTable {
    public void soft();
    public void pose();
}

