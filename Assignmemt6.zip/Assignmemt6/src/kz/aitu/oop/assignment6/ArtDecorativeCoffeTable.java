package kz.aitu.oop.assignment6;

public class ArtDecorativeCoffeTable implements CoffeeTable {
    @Override
    public void soft() {
        System.out.println("coffee table is not soft");
    }

    @Override
    public void pose() {
        System.out.println("You can lay on the table");
    }
}
