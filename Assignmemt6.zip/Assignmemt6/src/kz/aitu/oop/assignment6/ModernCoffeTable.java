package kz.aitu.oop.assignment6;

public class ModernCoffeTable implements CoffeeTable{
    @Override
    public void soft() {
        System.out.println("coffee table is not soft");
    }

    @Override
    public void pose() {
        System.out.println("You can lay on the table");
    }
}

