package kz.aitu.oop.assignment6;

public class Main {

    public static void main(String[] args) {
        FurnitureFactory FurFact = new ArtDecotariveFurnetureFactory();
        Chair ArtChair = FurFact.createChair();

        ArtChair.soft();
        ArtChair.pose();

    }
}

