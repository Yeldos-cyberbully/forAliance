package kz.aitu.oop.assignment6;

public class VictorianChair implements Chair {
    @Override
    public void soft() {
        System.out.println("chair is soft");
    }

    @Override
    public void pose() {
        System.out.println("You can sit on chair");
    }
}

